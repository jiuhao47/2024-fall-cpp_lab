#ifndef JJY_UTILS_H
#define JJY_UTILS_H

#define JJY_DEBUG_AST 0
#define JJY_DEBUG_IR 1
#define JJY_DEBUG_OBC_CHECK 1
#define JJY_DEBUG_SIGN "[j] "

#endif
